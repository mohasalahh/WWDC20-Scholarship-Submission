/*:
 # Earth's Layers Viewer
 ### A playground that is responsible for showing Earth's different internal layers in 3D using [SceneKit](https://developer.apple.com/documentation/scenekit) and [ARKit](https://developer.apple.com/documentation/arkit).
 ****
 
 ## Sources Descriptions
 - `Constants` : manages static constants used across the playground.
 - `Extensions` : manages global extensions that simplify things up.
 - `MainView` : used to initlize the main view that includes all the other views.
 - `EarthSceneView` : the main [SCNView](https://developer.apple.com/documentation/scenekit/scnview) used for managing and presenting the Earth 3D Object.
 - `AREarthSceneView` : an [ARSCNView](https://developer.apple.com/documentation/arkit/arscnview) used for managing and presenting the Earth 3D Object in real world(only runs on iPad).
 - `DetailsView` : used to initlize the view specific for showing each layers' info.
 - `InfoCollectionView` : resposible for generating a [UICollectionView](https://developer.apple.com/documentation/uikit/uicollectionview) that is used to show specific layer's details(eg. Temperature, Thickness, etc).
 - `TimelineCollectionView` : resposible for generating a [UICollectionView](https://developer.apple.com/documentation/uikit/uicollectionview) that is used to show Earth's layers in a timeline.
 
 ## View Hierarchy
 ````
 MainView->
 EarthSceneView->
 EarthNode
 
 AREarthSceneView->
 EarthNode
 
 TimelineCollectionView->
 LayerCollectionViewCell
 TemperatureCollectionViewCell
 
 DetailsView->
 InfoCollectionView
 InfoCollectionViewCell
 ````
 */

// Start Date: 5/7/2020 8:48 PM
// Finish Date 5/17/2020 10:06 AM

import PlaygroundSupport
/*:
 * Callout(Font License):
 Century Gothic is licensed under the SIL Open Font License, Version 1.1.
 - Callout(Texture License):
 Earth texture is obtained from [solarsystemscope.com](https://www.solarsystemscope.com/textures/) under the CC Attribution 4.0 International license.
 
 */

/*:
 - Note:
 The MainView will fit the size of the liveView while in landscape fullscreen mode. However, you can also customize the height.
 */
// for iPad use
//PlaygroundPage.current.liveView = ViewControllerPlaceholder()

// for Xcode use
PlaygroundPage.current.liveView = MainView(height: 500)
