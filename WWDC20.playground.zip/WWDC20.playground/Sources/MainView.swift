//
//  MainView.swift
//  This class is used to initlize the main view that includes all the other views.
//
//  WWDC20
//
//  Created by Mohamed Salah on 5/7/20.
//  Copyright © 2020 Mohamed Salah. All rights reserved.
//

import UIKit
import SceneKit
import ARKit

// Used to center the mainView in the liveView
public class ViewControllerPlaceholder: UIViewController {
    
    var mainViewHeight: CGFloat!
    
    public init(height: CGFloat? = nil) {
        super.init(nibName: nil, bundle: nil)
        mainViewHeight = height
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    var mainView: MainView!
    public override func viewDidLoad() {
        super.viewDidLoad()
        
        var height = UIScreen.main.bounds.height
        if height > UIScreen.main.bounds.width {
            height = UIScreen.main.bounds.width
        }
        view.backgroundColor = .black
        mainView = MainView(height: mainViewHeight ?? height*0.734)
        view.addSubview(mainView)
        
        let blurEffect = UIBlurEffect(style: UIBlurEffect.Style.dark)
        let blurEffectView = UIVisualEffectView(effect: blurEffect)
        blurEffectView.frame = view.bounds
        blurEffectView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        blurView.addSubview(blurEffectView)
        
        blurLabel.text = "Please switch to landscape full screen mode to continue experiencing the playground."
        blurLabel.setupLabel(color: .white, fontWeight: .Bold, fontSize: 19)
        
        blurView.alpha = 0
        blurView.addSubview(blurLabel)
        view.addSubview(blurView)
    }
    var once = true
    
    var blurView = UIView()
    var blurLabel = UILabel()
    
    public override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        
        mainView.frame.origin = CGPoint(x: (view.frame.width/2)-(mainView.frame.width/2), y: (view.frame.height/2)-(mainView.frame.height/2))
        
        blurView.frame = view.bounds
        blurLabel.frame = view.bounds
        
        UIView.animate(withDuration: 0.3) {
            self.blurView.alpha = (self.view.bounds.height > self.view.bounds.width) || UIScreen.main.bounds.height > UIScreen.main.bounds.width ? 1 : 0
        }
        
    }
}

public class MainView: UIView {
    
    var viewHeight: CGFloat
    var viewWidth: CGFloat
    
    var backBtnView: UIView!
    var mainViewInfo: UIView!
    
    var tapGest: UITapGestureRecognizer!
    
    var arScene: AREarthSceneView!
    var sceneView: EarthSceneView!
    
    var viewInARView: UIView!
    var timelineView: UIView!
    var detailsView: DetailsView!
    
    
    public init(height: CGFloat) {
        
        viewHeight = height
        viewWidth = (viewHeight*889)/518
        
        super.init(frame: CGRect(x: 0, y: 0, width: viewWidth, height: viewHeight))

        // Registering our fonts
        CTFontManagerRegisterFontsForURL(Bundle.main.url(forResource: "gothic-reg", withExtension: "ttf")! as CFURL, CTFontManagerScope.process, nil)
        CTFontManagerRegisterFontsForURL(Bundle.main.url(forResource: "gothic-bold", withExtension: "ttf")! as CFURL, CTFontManagerScope.process, nil)
        
        // Stars background:
        
        let starsImg = UIImageView(frame: bounds)
        starsImg.image = UIImage(named: "star")
        UIView.animate(withDuration: 7, delay: 0.3, options: [.curveEaseInOut, .repeat, .autoreverse], animations: {
            starsImg.transform = CGAffineTransform(scaleX: 1.1, y: 1.1)
            starsImg.alpha = 0.9
        })
        
        // Header View:
        
        backBtnView = UIView(frame: CGRect(x: viewWidth*0.0258, y: 0, width: viewWidth*0.07856, height: viewHeight*0.0656))
        backBtnView.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(goBack)))
        backBtnView.alpha = 0
        
        let backBtnIco = UIImageView(frame: CGRect(x: 0, y: 0, width: backBtnView.frame.width*0.2, height: backBtnView.frame.height))
        backBtnIco.image = UIImage(named: "backBtn")
        backBtnIco.contentMode = .scaleAspectFit
        
        let backBtnHeight = "Back".height(withConstrainedWidth: backBtnView.frame.width*0.8, font: UIFont(name: "CenturyGothic-Bold", size: backBtnView.frame.height*0.47)!)
        let backBtnLabel = UILabel(frame: CGRect(x: backBtnIco.frame.maxX, y: (backBtnView.frame.height/2)-(backBtnHeight/2), width: backBtnView.frame.width*0.8, height: backBtnHeight))
        backBtnLabel.text = "Back"
        backBtnLabel.setupLabel(color: .white, fontWeight: .Bold, fontSize: backBtnView.frame.height*0.47)
        
        backBtnView.addSubview(backBtnIco)
        backBtnView.addSubview(backBtnLabel)
        
        
        let logo = UIImageView(frame: CGRect(x: viewWidth-(viewWidth*0.0258)-(viewHeight*0.0694), y: viewWidth*0.0258, width: viewHeight*0.0694, height: viewHeight*0.0694))
        logo.image = UIImage(named: "logo")
        logo.contentMode = .scaleAspectFit
        logo.alpha = 0.3
        
        // Earth scene view:
        sceneView = EarthSceneView(frame: bounds)
        
        tapGest = UITapGestureRecognizer(target: self, action: #selector(tapGestAc(sender:)))
        tapGest.numberOfTapsRequired = 2
        
        sceneView.addGestureRecognizer(tapGest)
        
        // Home View:
        
        let titleSubLabel = UILabel(frame: CGRect(x: 0, y: viewHeight*0.083, width: viewWidth, height: viewHeight*0.0333))
        titleSubLabel.text = "A journey to the center of the Earth"
        titleSubLabel.setupLabel(color: .colorMain, fontWeight: .Regular)
        titleSubLabel.applyCharacterSpacing(value: viewHeight/200)
        
        let titleLabel = UILabel(frame: CGRect(x: 0, y: viewHeight*0.14, width: viewWidth, height: viewHeight*0.0965))
        titleLabel.text = "EARTH'S CORE"
        titleLabel.setupLabel(color: .white, fontWeight: .Bold)
        titleLabel.applyCharacterSpacing(value: viewHeight/40)
        
        let desLabel = UILabel(frame: CGRect(x: (viewWidth/2)-(viewWidth*0.691*0.5), y: viewHeight*0.26, width: viewWidth*0.691, height: viewHeight*0.15444))
        desLabel.text = "While we can't see deep into the Earth, geologists were able to visualize how Earth looks from the inside. And we developers, using technology, are here for their help. Just like a kid's jawbreaker, Earth consists of layers that differ in composition and generally get hotter and higher in pressure as you move toward the center of the planet."
        desLabel.setupLabel(color: .white, fontWeight: .Regular)
        
        let startBtn = UIButton(frame: CGRect(x: (viewWidth/2)-(viewWidth*0.154*0.5), y: viewHeight*0.471, width: viewWidth*0.154, height: viewHeight*0.06177))
        startBtn.setTitleColor(.colorMain, for: .normal)
        startBtn.setTitle("Get Started", for: .normal)
        startBtn.addTarget(self, action: #selector(startBtnAc), for: .touchUpInside)
        
        startBtn.titleLabel?.setupLabel(color: .colorMain, fontWeight: .Bold, fontSize: startBtn.frame.height*0.4)
        
        let startBtnLayer = CAShapeLayer()
        startBtnLayer.path = UIBezierPath(roundedRect: startBtn.bounds, cornerRadius: startBtn.frame.height/2).cgPath
        startBtnLayer.fillColor = UIColor.white.cgColor
        
        startBtnLayer.shadowColor = UIColor.white.cgColor
        startBtnLayer.shadowOffset = CGSize(width: 0, height: 0)
        startBtnLayer.shadowRadius = 5
        startBtnLayer.shadowOpacity = 1
        
        startBtn.layer.insertSublayer(startBtnLayer, at: 0)
        
        mainViewInfo = UIView(frame: CGRect(x: 0, y: 0, width: viewWidth, height: startBtn.frame.maxY))
        
        // ViewinAR View:
        
        viewInARView = UIView(frame: CGRect(x: (viewWidth/2)-(viewWidth*0.13*0.5), y: 0, width: viewWidth*0.13, height: viewHeight*0.059))
        
        let arBGLayer = CAShapeLayer()
        arBGLayer.path = UIBezierPath(roundedRect: viewInARView.bounds, cornerRadius: viewInARView.frame.height/2).cgPath
        arBGLayer.fillColor = UIColor.white.withAlphaComponent(0.8).cgColor
        
        viewInARView.layer.addSublayer(arBGLayer)
        
        let arIco = UIImageView(frame: CGRect(x: viewInARView.frame.width/10, y: (viewInARView.frame.height/2)-(viewInARView.frame.height*0.61*0.5), width: viewInARView.frame.height*0.61, height: viewInARView.frame.height*0.61))
        arIco.image = UIImage(named: "ar")
        
        let arLabel = UILabel(frame: CGRect(x: arIco.frame.maxX, y: (viewInARView.frame.height/2)-(viewInARView.frame.height*0.25), width: viewInARView.frame.width*0.66, height: viewInARView.frame.height/2))
        arLabel.text = "View in AR"
        arLabel.setupLabel(color: UIColor.darkGray, fontWeight: .Bold)
        
        viewInARView.addSubview(arIco)
        viewInARView.addSubview(arLabel)
        
        viewInARView.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(viewInARGestAc(sender:))))
        
        // Timeline View:
        
        timelineView = UIView(frame: CGRect(x: 0, y: 0, width: viewWidth, height: 0))
        
        let timelineCollectionView = TimelineCollectionView(frame: CGRect(x: (viewWidth/2)-(viewWidth*0.819*0.5), y: viewInARView.frame.height/2, width: viewWidth*0.819, height: viewHeight*0.148))
        
        let tapNote = UILabel(frame: CGRect(x: 0, y: timelineCollectionView.frame.maxY+(timelineCollectionView.frame.height*0.1), width: viewWidth, height: timelineCollectionView.frame.height*0.2))
        tapNote.text = "Tap on layer to view info"
        tapNote.setupLabel(color: .white, fontWeight: .Regular)
        
        timelineView.frame.size.height += tapNote.frame.maxY+(timelineCollectionView.frame.height*0.1)+viewInARView.frame.height
        timelineView.frame.origin.y += viewHeight-timelineView.frame.size.height+(viewHeight*0.27)
        timelineView.alpha = 0
        
        timelineView.addSubview(viewInARView)
        timelineView.addSubview(timelineCollectionView)
        timelineView.addSubview(tapNote)
        
        // Details View:
        
        detailsView = DetailsView(frame: CGRect(x: viewWidth*0.53, y: viewHeight*0.13, width: viewWidth*0.426, height: viewHeight*0.87))
        
        // Adding subViews:
        
        addSubview(starsImg)
        
        addSubview(sceneView)
        
        mainViewInfo.addSubview(titleSubLabel)
        mainViewInfo.addSubview(titleLabel)
        mainViewInfo.addSubview(desLabel)
        mainViewInfo.addSubview(startBtn)
        addSubview(mainViewInfo)
        
        addSubview(timelineView)
        //        addSubview(viewInARView)
        addSubview(detailsView)
        
        addSubview(backBtnView)
        addSubview(logo)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    // 0 = Home, 1 = Timeline, 2 = AR, 3 = Details
    var viewIndex = 0
    
    /**
     BackBtn Action
     */
    @objc func goBack() {
        if viewIndex == 3 {
            goTimeline()
        }else if viewIndex == 2 {
            dismissAR()
        }else if viewIndex == 1 {
            goHome()
        }
    }
    
    /**
     Dismiss the ARKit View and transform the node to the SceneKit scene
     */
    func dismissAR() {
        viewIndex = 1
        
        arScene.session.pause()
        
        sceneView.earthNode.removeFromParentNode()
        sceneView.earthNode.position.y = 0
        sceneView.earthNode.scale = SCNVector3Make(1, 1, 1)
        sceneView.earthNode.scaleParticles(scale: 1/0.25)
        sceneView.scene?.rootNode.addChildNode(sceneView.earthNode)
        
        UIView.animate(withDuration: 0.5, delay: 0, options: [.curveEaseInOut], animations: {
            self.arScene.alpha = 0
        }, completion: {finished in
            self.arScene.delegate = nil
            self.arScene.removeFromSuperview()
            self.arScene = nil
        })
    }
    
    /**
     Show timeline view and adjust camera again
     */
    func goTimeline() {
        viewIndex = 1
        sceneView.panGest.isEnabled = true
        
        UIView.animate(withDuration: 0.5, delay: 0, options: [.curveEaseInOut], animations: {
            self.timelineView.alpha = 1
            self.detailsView.alpha = 0
        })
        
        sceneView.earthNode.childNode(withName: "SecondHalf", recursively: true)!.runAction(SCNAction.fadeIn(duration: 1.5).applyTiming())
        
        let mainHalf = sceneView.earthNode.mainHalf
        sceneView.earthNode.inner.fadeIn(duration: 1.5)
        
        for node in mainHalf!.childNodes {
            node.fadeIn(duration: 1.5)
        }
        
        sceneView.moveCamera(position: SCNVector3Make(-0.1, -0.3, 3.2), duration: 1.5)
        sceneView.orbitCamera(y: 0.23, duration: 1.5)
    }
    
    /**
     Hide timeline and reassemble Earth once again
     */
    func goHome() {
        viewIndex = 0
        
        UIView.animate(withDuration: 1.5, delay: 0.3, options: [.curveEaseInOut], animations: {
            
            self.mainViewInfo.frame.origin.y += self.mainViewInfo.frame.height*0.2
            for i in self.mainViewInfo.subviews {
                i.frame.origin.y += i.frame.height*0.3
            }
            self.mainViewInfo.alpha = 1
            
            self.backBtnView.alpha = 0
            self.backBtnView.frame.origin.y -= self.backBtnView.frame.origin.x
            
            self.timelineView.alpha = 0
            self.timelineView.frame.origin.y += self.viewHeight*0.22
        })
        
        sceneView.earthNode.startRotation()
        
        // Reset layers' nodes positions
        
        sceneView.earthNode.removeParticles()
        sceneView.earthNode.secondHalf.runAction(SCNAction.move(to: SCNVector3Make(0, 0, 0), duration: 1.5).applyTiming())
        sceneView.earthNode.outerSecond.runAction(SCNAction.move(to: SCNVector3Make(0, 0, 0), duration: 1.5).applyTiming())
        sceneView.earthNode.mantleSecond.runAction(SCNAction.move(to: SCNVector3Make(0, 0, 0), duration: 1.5).applyTiming())
        
        
        sceneView.earthNode.mainHalf.runAction(SCNAction.move(to: SCNVector3Make(0, 0, 0), duration: 1.5).applyTiming())
        
        sceneView.earthNode.outerMain.removeAllActions()
        sceneView.earthNode.outerMain.runAction(SCNAction.move(to: SCNVector3Make(0, 0, 0), duration: 1.5).applyTiming())
        
        sceneView.earthNode.mantleMain.removeAllActions()
        sceneView.earthNode.mantleMain.runAction(SCNAction.move(to: SCNVector3Make(0, 0, 0), duration: 1.5).applyTiming())
        
        sceneView.earthNode.inner.removeAllActions()
        sceneView.earthNode.inner.runAction(SCNAction.move(to: SCNVector3Make(0, 0, 0), duration: 1.5).applyTiming())
        
        sceneView.moveCamera(position: SCNVector3Make(0, 1.3, 1.8), duration: 1.5)
        sceneView.orbitCamera(duration: 1.5)
    }
    
    /**
     Show and update DetailsView with a specific Earth layer
     - parameters:
     - layerPosition: Earth's layer index from left to right(eg. 0 for crust)
     */
    func goToDetails(layerPosition: Int) {
        viewIndex = 3
        
        sceneView.panGest.isEnabled = false
        
        UIView.animate(withDuration: 1.5, delay: 0.3, options: [.curveEaseInOut], animations: {
            self.timelineView.alpha = 0
            self.detailsView.alpha = 1
        })
        
        detailsView.updateDetails(layerIndex: layerPosition)
        
        sceneView.earthNode.secondHalf.fadeOut(duration: 0.8)
        
        for (index, node) in sceneView.earthNode.layersArrayMain.enumerated() {
            if index != layerPosition {
                node.fadeOpacity(to: 0.3, duration: 1.5)
            }
        }
        
        sceneView.moveCamera(position: SCNVector3Make(0.29, 0, 2.6), duration: 1.5)
        sceneView.orbitCamera(y: 0.25, duration: 1.5)
    }
    
    @objc func tapGestAc(sender: UITapGestureRecognizer) {
        sender.isEnabled = false
        goBack()
    }
    
    @objc func viewInARGestAc(sender: UITapGestureRecognizer) {
        viewIndex = 2
        
        arScene = AREarthSceneView(frame: sceneView.bounds)
        insertSubview(arScene, belowSubview: backBtnView)
        
        let configuration = ARWorldTrackingConfiguration()
        configuration.planeDetection = [.horizontal]
        arScene.session.run(configuration)
        
        UIView.animate(withDuration: 0.5, delay: 0, options: [.curveEaseInOut], animations: {
            self.arScene.alpha = 1
        })
    }
    
    @objc func startBtnAc(sender: UIButton) {
        viewIndex = 1
        
        UIView.animate(withDuration: 0.9, delay: 0.3, options: [.curveEaseInOut], animations: {
            self.mainViewInfo.frame.origin.y -= self.mainViewInfo.frame.height*0.2
            for i in self.mainViewInfo.subviews {
                i.frame.origin.y -= i.frame.height*0.3
            }
            self.mainViewInfo.alpha = 0
            
            self.backBtnView.alpha = 1
            self.backBtnView.frame.origin.y += self.backBtnView.frame.origin.x
            
            self.timelineView.alpha = 1
            self.timelineView.frame.origin.y -= self.viewHeight*0.22
        })
        
        // Assembling Earth node into to halfs:
        
        sceneView.earthNode.stopRotation()
        
        sceneView.earthNode.secondHalf.runAction(SCNAction.move(to: SCNVector3Make(0.55, 0, 0), duration: 1.5).applyTiming())
        sceneView.earthNode.outerSecond.runAction(SCNAction.move(to: SCNVector3Make(-0.045, 0, 0), duration: 1.5).applyTiming())
        sceneView.earthNode.mantleSecond.runAction(SCNAction.move(to: SCNVector3Make(-0.026, 0, 0), duration: 1.5).applyTiming())
        
        sceneView.earthNode.mainHalf.runAction(SCNAction.move(to: SCNVector3Make(-1.1, 0, 0), duration: 1.5).applyTiming())
        
        sceneView.earthNode.outerMain.runAction(SCNAction.sequence([SCNAction.move(to: SCNVector3Make(0.826, 0, 0), duration: 1.5).applyTiming(), SCNAction.repeatForever(SCNAction.group([SCNAction.sequence([SCNAction.move(to: SCNVector3Make(0.78, 0, 0), duration: 11).applyTiming(), SCNAction.move(to: SCNVector3Make(0.826, 0, 0), duration: 10).applyTiming()]), SCNAction.rotateBy(x: 2 * .pi, y: 0, z: 0, duration: 190).applyTiming()]))]))
        sceneView.earthNode.mantleMain.runAction(SCNAction.sequence([SCNAction.move(to: SCNVector3Make(0.468, 0, 0), duration: 1.5).applyTiming(), SCNAction.repeatForever(SCNAction.group([SCNAction.sequence([SCNAction.move(to: SCNVector3Make(0.48, 0, 0), duration: 15).applyTiming(), SCNAction.move(to: SCNVector3Make(0.468, 0, 0), duration: 13).applyTiming()]), SCNAction.rotateBy(x: -2 * .pi, y: 0, z: 0, duration: 200).applyTiming()]))]))
        
        sceneView.earthNode.inner.runAction(SCNAction.repeatForever(SCNAction.group([SCNAction.sequence([SCNAction.move(to: SCNVector3Make(-0.05, 0, 0), duration: 10).applyTiming(), SCNAction.move(to: SCNVector3Make(0, 0, 0), duration: 14).applyTiming()]), SCNAction.rotateBy(x: -2 * .pi, y: 2 * .pi, z: 0, duration: 150)])))
        
        
        sceneView.moveCamera(position: SCNVector3Make(-0.1, -0.3, 3.2), duration: 1.5)
        sceneView.orbitCamera(y: 0.23, duration: 1.5)
        
        sceneView.earthNode.addParticles()
    }
}

