//
//  InfoCollectionView.swift
//  This class is resposible for generating a CollectionView that is used to show layers' info.
//
//  WWDC20
//
//  Created by Mohamed Salah on 5/13/20.
//  Copyright © 2020 Mohamed Salah. All rights reserved.
//

import UIKit

public class InfoCollectionView: UICollectionView, UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout  {
    
    var data: [InfoItem] = [] {
        didSet {
            // Reload data every time the 'data' var is updated
            reloadData()
        }
    }
    
    public init(frame: CGRect) {
        let m = UICollectionViewFlowLayout()
        super.init(frame: frame, collectionViewLayout: m)
        
        clipsToBounds = false
        m.minimumInteritemSpacing = 0
        
        setCollectionViewLayout(m, animated: false)
        dataSource = self
        delegate = self
        backgroundColor = .clear
        
        register(InfoCollectionViewCell.self, forCellWithReuseIdentifier: "cell")
        
    }
    
    required  init(coder aDecoder: NSCoder) {
        fatalError("This class does not support NSCoding")
    }
    
    // MARK: - UICollectionViewDelegate
    
    public func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    
    public func collectionView(_ collectionView: UICollectionView,
                               numberOfItemsInSection section: Int) -> Int {
        return data.count
    }
    
    public func collectionView(_ collectionView: UICollectionView,
                               cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath) as! InfoCollectionViewCell
        let item = data[indexPath.row]
        
        cell.ico.image = UIImage(named: item.type.ico)
        
        cell.titleLabel.text = item.type.title.uppercased()
        cell.contentLabel.text = String(describing: item.content)+" "+item.type.unit
        
        return cell
        
    }
    
    public func collectionView(_ collectionView: UICollectionView,
                               layout collectionViewLayout: UICollectionViewLayout,
                               sizeForItemAt indexPath: IndexPath) -> CGSize {
        // The width of the collectionView is divided equally among the cells
        return CGSize(width: frame.width*0.47, height: frame.height*0.45)
    }
}

public class InfoCollectionViewCell: UICollectionViewCell {
    
    var ico: UIImageView! /* Info icon image(eg. temeprature icon) */
    var titleLabel: UILabel! /* Info type label(eg. temeprature) */
    var contentLabel: UILabel! /* Info content label(eg. 2700 °C) */
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        // Nothing interesting: designing the cell
        
        backgroundColor = .clear
        
        let width = frame.size.width
        let height = frame.size.height
        
        let cellFrame = CAShapeLayer()
        cellFrame.path = UIBezierPath(rect: bounds).cgPath
        cellFrame.fillColor = UIColor.clear.cgColor
        cellFrame.lineWidth = 1
        cellFrame.strokeColor = UIColor.white.cgColor
        
        layer.addSublayer(cellFrame)
        
        ico = UIImageView(frame: CGRect(x: ((width-(width*0.62)-(width*0.049))/2)-(height/4), y: height/4, width: height/2, height: height/2))
        ico.contentMode = .scaleAspectFit
        
        let textView = UIView(frame: CGRect(x: width-(width*0.62)-(width*0.049), y: ico.frame.minY, width: width*0.62, height: ico.frame.height))
        titleLabel = UILabel(frame: CGRect(x: 0, y: 0, width: textView.frame.width, height: textView.frame.height*0.325))
        titleLabel.setupLabel(color: .lightGray, fontWeight: .Regular, alignment: .left)
        
        contentLabel = UILabel(frame: CGRect(x: 0, y: titleLabel.frame.maxY+(textView.frame.height*0.075), width: titleLabel.frame.width, height: textView.frame.height*0.7))
        contentLabel.setupLabel(color: .white, fontWeight: .Bold, alignment: .left)
        
        addSubview(ico)
        
        textView.addSubview(titleLabel)
        textView.addSubview(contentLabel)
        
        addSubview(textView)
    }
    
    required  init(coder aDecoder: NSCoder) {
        fatalError("This class does not support NSCoding")
    }
}
