//
//  DetailsView.swift
//  This class creates and updates a specifc layer's details.
//
//  WWDC20
//
//  Created by Mohamed Salah on 5/9/20.
//  Copyright © 2020 Mohamed Salah. All rights reserved.
//

import UIKit

public class DetailsView: UIView {
    
    var titleLabel: UILabel! /* layer's name */
    var desLabel: UILabel!  /* layer's description */
    var infoCollectionView: InfoCollectionView!  /* layer's info */
    
    public override init(frame: CGRect) {
        super.init(frame: frame)
        
        // Nothing interesting: designing the view
        
        alpha = 0
        
        titleLabel = UILabel(frame: CGRect(x: 0, y: 0, width: frame.width, height: frame.height*0.148))
        titleLabel.setupLabel(color: .white, fontWeight: .Bold, alignment: .left)
        
        desLabel = UILabel(frame: CGRect(x: 0, y: frame.height*0.15, width: frame.width, height: frame.height*0.23))
        desLabel.setupLabel(color: .white, fontWeight: .Regular, alignment: .left)
        
        infoCollectionView = InfoCollectionView(frame: CGRect(x: 0, y: desLabel.frame.maxY+(frame.height*0.09), width: frame.width, height: frame.height*0.4))
        
        addSubview(titleLabel)
        addSubview(desLabel)
        addSubview(infoCollectionView)
        
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    /**
     Function used to update the DetailsView's data.
     - parameters:
     - layerIndex: Earth's layer index from left to right(eg. 0 for crust)
     */
    func updateDetails(layerIndex: Int) {
        let layerData = StaticData.layersData[layerIndex]
        
        titleLabel.text = layerData.name
        desLabel.text = layerData.des
        
        infoCollectionView.data = layerData.info
    }
}
