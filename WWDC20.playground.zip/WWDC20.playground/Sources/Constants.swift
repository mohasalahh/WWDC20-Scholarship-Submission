//
//  Constants.swift
//  This class manages static constants used across the playground.
//
//  WWDC20
//
//  Created by Mohamed Salah on 5/7/20.
//  Copyright © 2020 Mohamed Salah. All rights reserved.
//

import Foundation

public struct EarthLayer {
    let name: String
    let des: String
    let info: [InfoItem]
}

public struct InfoItem {
    var type: InfoType
    var content: Any
}

public enum InfoType {
    case Temperature
    case Thickness
    case PercentEarth
    case MainMaterial
    
    var ico: String {
        switch self {
        case .Temperature:
            return "temp"
        case .Thickness:
            return "thickness"
        case .PercentEarth:
            return "percent"
        case .MainMaterial:
            return "comet"
        }
    }
    
    var title: String {
        switch self {
        case .Temperature:
            return "Temperature"
        case .Thickness:
            return "Thickness"
        case .PercentEarth:
            return "% of Earth"
        case .MainMaterial:
            return "Main Material"
        }
    }
    
    var unit: String {
        switch self {
        case .Temperature:
            return "°C"
        case .Thickness:
            return "km"
        case .PercentEarth:
            return "%"
        case .MainMaterial:
            return ""
        }
    }
}

public struct TimelineItem {
    var name: String! = nil /* Layer name */
    var depth: Int! = nil /* km */
    var temp: Int! = nil /* °C */
}

public struct StaticData {
    public static let layersData = [
        EarthLayer(name: "Crust", des: "Earth's crust is what we walk on every day. It is the thin (relatively) outermost layer that wraps around the Earth. The crust is split into two types, continental and oceanic. Earth's crust is 5 to 70 km thick.", info: [
            InfoItem(type: .Temperature, content: 300),
            InfoItem(type: .Thickness, content: 70),
            InfoItem(type: .PercentEarth, content: 1),
            InfoItem(type: .MainMaterial, content: "Oxygen")
        ]),
        EarthLayer(name: "Mantle", des: "Just below the crust lies the mantle. The mantle is semi-liquid, sort of like a malleable plastic and makes up 84% of Earth's volume. Earth's mantle is 2,900 km thick and is broken down into 3 main zones, the lithosphere, asthenosphere, and mesosphere.", info: [
            InfoItem(type: .Temperature, content: 3300),
            InfoItem(type: .Thickness, content: 2900),
            InfoItem(type: .PercentEarth, content: 84),
            InfoItem(type: .MainMaterial, content: "Magnesium")
        ]),
        EarthLayer(name: "Outer Core", des: "The outer core lies beneath the mantle. This liquid iron and nickel layer spins as the planet rotates and creates Earth's magnetic field. This magnetic field helps to protect us from the Sun's solar radiation. The outer core is approximately 2,200 km thick.", info: [
            InfoItem(type: .Temperature, content: 4400),
            InfoItem(type: .Thickness, content: 2200),
            InfoItem(type: .PercentEarth, content: 9),
            InfoItem(type: .MainMaterial, content: "Nickel")
        ]),
        EarthLayer(name: "Inner Core", des: "The inner core is the deepest layer on Earth. It is also made up of iron and nickel but the pressure is so high that it is no longer liquid. The temperature in the inner core is as hot as the surface of the sun. Earth's inner core is 1,230 to 1,530 km thick.", info: [
            InfoItem(type: .Temperature, content: 5630),
            InfoItem(type: .Thickness, content: 1250),
            InfoItem(type: .PercentEarth, content: 6),
            InfoItem(type: .MainMaterial, content: "Iron")
        ])
    ]
    
    public static let timelineData = [TimelineItem(name: "Crust", depth: 70), TimelineItem(temp: 2350), TimelineItem(name: "Mantle", depth: 2965), TimelineItem(temp: 4210), TimelineItem(name: "Outer Core", depth: 5130), TimelineItem(temp: 4915), TimelineItem(name: "Inner Core", depth: 6700)]
}

// Font weight
public enum FontWeight {
    case Regular
    case Bold
    
    var fontName : String {
        switch self {
        case .Regular:
            return "CenturyGothic"
        case .Bold:
            return "CenturyGothic-Bold"
        }
    }
}
