//
//  Extensions.swift
//  This class manages global extensions that simplify things up.
//
//  WWDC20
//
//  Created by Mohamed Salah on 5/7/20.
//  Copyright © 2020 Mohamed Salah. All rights reserved.
//

import UIKit
import SceneKit

public extension UIColor {
    //used for clarity
    convenience init(red: CGFloat, green: CGFloat, blue: CGFloat) {
        self.init(red: red / 255.0, green: green / 255.0, blue: blue / 255.0, alpha: 1.0)
    }
    convenience init(red: CGFloat, green: CGFloat, blue: CGFloat, alph: CGFloat) {
        self.init(red: red / 255.0, green: green / 255.0, blue: blue / 255.0, alpha: alph)
    }
    
    // Colors used in the playground
    static var colorMain: UIColor {
        return UIColor(red: 26, green: 81, blue: 255)
    }
    static var colorMainLight: UIColor {
        return UIColor(red: 111, green: 132, blue: 246)
    }
    static var lightBlack: UIColor {
        return UIColor(red: 15, green: 15, blue: 15)
    }
    static var myGray: UIColor {
        return UIColor(red: 174, green: 174, blue: 174)
    }
}
public extension UILabel {
    // Simple Extension to simplify setting labels' styles
    func setupLabel(color: UIColor, fontWeight: FontWeight, fontSize: CGFloat? = nil, alignment: NSTextAlignment = .center) {
        textColor = color
        textAlignment = alignment
        
        // Used for safety
        adjustsFontSizeToFitWidth = true
        numberOfLines = 0
        
        if let fontSize = fontSize {
            font = UIFont(name: fontWeight.fontName, size: fontSize)
        }else {
            font = UIFont(name: fontWeight.fontName, size: 100)
        }
    }
    
    // Adding character spacing using AttributedStrings
    func applyCharacterSpacing(value: CGFloat) {
        let attributedString = NSMutableAttributedString(string: text!)
        attributedString.addAttribute(NSAttributedString.Key.kern, value: value, range: NSRange(location: 0, length: attributedString.length))
        attributedText = attributedString
    }
}

public extension String {
    // Getting the exact height of text with a specific font size (https://stackoverflow.com/a/30450559/4724060)
    func height(withConstrainedWidth width: CGFloat, font: UIFont) -> CGFloat {
        let constraintRect = CGSize(width: width, height: .greatestFiniteMagnitude)
        let boundingBox = self.boundingRect(with: constraintRect, options: .usesLineFragmentOrigin, attributes: [NSAttributedString.Key.font: font], context: nil)
        
        return ceil(boundingBox.height)
    }
}

public extension SCNAction {
    // Make a SCNAction's animation smooth
    func applyTiming()-> SCNAction {
        self.timingMode = .easeInEaseOut
        return self
    }
}

public extension SCNNode {
    // Simplifying node's opacity animations
    func fadeOpacity(to: CGFloat, duration: TimeInterval) {
        runAction(SCNAction.fadeOpacity(to: to, duration: duration).applyTiming())
    }
    func fadeIn(duration: TimeInterval) {
        runAction(SCNAction.fadeIn(duration: duration).applyTiming())
    }
    func fadeOut(duration: TimeInterval) {
        runAction(SCNAction.fadeOut(duration: duration).applyTiming())
    }
}
