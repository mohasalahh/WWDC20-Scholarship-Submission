//
//  TimelineCollectionView.swift
//  This class is resposible for generating a CollectionView that is used to show layers timeline.
//
//  WWDC20
//
//  Created by Mohamed Salah on 5/10/20.
//  Copyright © 2020 Mohamed Salah. All rights reserved.
//

import UIKit

public class TimelineCollectionView: UICollectionView, UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout  {
    
    public init(frame: CGRect) {
        let m = UICollectionViewFlowLayout()
        super.init(frame: frame, collectionViewLayout: m)
        
        m.minimumInteritemSpacing = 0
        
        setCollectionViewLayout(m, animated: false)
        dataSource = self
        delegate = self
        backgroundColor = .clear
        
        // Adding the center timeline pipe
        let timelineBG = CAShapeLayer()
        timelineBG.path = UIBezierPath(roundedRect: CGRect(x: frame.width/7/2, y: (frame.height/2)-(frame.height*0.0389*0.5), width: frame.width-(frame.width/7), height: frame.height*0.0389), cornerRadius: frame.height*0.0389*0.5).cgPath
        timelineBG.fillColor = UIColor.white.cgColor
        
        layer.insertSublayer(timelineBG, at: 0)
        
        register(LayerCollectionViewCell.self, forCellWithReuseIdentifier: "layerCell")
        register(TemperatureCollectionViewCell.self, forCellWithReuseIdentifier: "tempCell")
        
    }
    required  init(coder aDecoder: NSCoder) {
        fatalError("This class does not support NSCoding")
    }
    
    // MARK: - UICollectionViewDelegate
    
    public func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    
    public func collectionView(_ collectionView: UICollectionView,
                               numberOfItemsInSection section: Int) -> Int {
        return StaticData.timelineData.count
    }
    
    public func collectionView(_ collectionView: UICollectionView,
                               cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let item = StaticData.timelineData[indexPath.row]
        if let temp = item.temp {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "tempCell", for: indexPath) as! TemperatureCollectionViewCell
            cell.tempLabel.text = String(temp)+" °C"
            return cell
        }else {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "layerCell", for: indexPath) as! LayerCollectionViewCell
            cell.depthLabel.text = String(item.depth)+" km"
            cell.nameLabel.text = String(item.name)
            return cell
        }
    }
    
    public func collectionView(_ collectionView: UICollectionView,
                               layout collectionViewLayout: UICollectionViewLayout,
                               sizeForItemAt indexPath: IndexPath) -> CGSize {
        // The width of the collectionView is divided equally among the cells
        return CGSize(width: frame.width/CGFloat(collectionView.numberOfItems(inSection: 0)), height: frame.height)
    }
    
    public func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        // Only recieve clicks from layers cell and not temperature
        if indexPath.row % 2 == 0 {
            (superview?.superview as! MainView).goToDetails(layerPosition: indexPath.row/2)
        }
    }
}

public class LayerCollectionViewCell: UICollectionViewCell {
    
    var depthLabel: UILabel!
    var nameLabel: UILabel!
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        // Nothing interesting: designing the cell
        
        let width = frame.size.width
        let height = frame.size.height
        
        let circleRect = CGRect(x: (width/2)-(height*0.22*0.5), y: (height/2)-(height*0.22*0.5), width: height*0.22, height: height*0.22)
        
        let circleLayer = CAShapeLayer()
        circleLayer.path = UIBezierPath(ovalIn: circleRect).cgPath
        circleLayer.fillColor = UIColor.white.cgColor
        
        layer.addSublayer(circleLayer)
        
        depthLabel = UILabel(frame: CGRect(x: 0, y: circleRect.minY-(height*0.07)-(height*0.19), width: width, height: height*0.19))
        depthLabel.text = "70 km"
        depthLabel.setupLabel(color: .white, fontWeight: .Bold, fontSize: height*0.15)
        
        addSubview(depthLabel)
        
        nameLabel = UILabel(frame: CGRect(x: 0, y: circleRect.maxY+(height*0.05), width: width, height: height*0.22))
        nameLabel.text = "Inner Core"
        nameLabel.setupLabel(color: .white, fontWeight: .Bold, fontSize: height*0.22)
        
        addSubview(nameLabel)
    }
    
    required  init(coder aDecoder: NSCoder) {
        fatalError("This class does not support NSCoding")
    }
}

public class TemperatureCollectionViewCell: UICollectionViewCell {
    
    var tempLabel: UILabel!
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        // Nothing interesting: designing the cell
        
        let width = frame.size.width
        let height = frame.size.height
        
        let circleRect = CGRect(x: (width/2)-(height*0.11*0.5), y: (height/2)-(height*0.11*0.5), width: height*0.11, height: height*0.11)
        
        let circleLayer = CAShapeLayer()
        circleLayer.path = UIBezierPath(ovalIn: circleRect).cgPath
        circleLayer.fillColor = UIColor.white.cgColor
        
        layer.addSublayer(circleLayer)
        
        tempLabel = UILabel(frame: CGRect(x: 0, y: circleRect.maxY+(height*0.05), width: width, height: height*0.22))
        tempLabel.setupLabel(color: .white, fontWeight: .Bold, fontSize: height*0.14)
        
        addSubview(tempLabel)
    }
    
    required  init(coder aDecoder: NSCoder) {
        fatalError("This class does not support NSCoding")
    }
}
