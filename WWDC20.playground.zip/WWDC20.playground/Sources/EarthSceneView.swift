//
//  EarthSceneView.swift
//  Custom class for creating and managing the SceneKit view for showing the Earth object.
//
//  WWDC20
//
//  Created by Mohamed Salah on 5/8/20.
//  Copyright © 2020 Mohamed Salah. All rights reserved.
//

import SceneKit
import UIKit

public class EarthSceneView: SCNView {
    
    // Pan Gesture responsible for the camera view
    var panGest: UIPanGestureRecognizer!
    
    // The camera node used to position how the scene looks like
    let cameraNode = SCNNode()
    
    // The main Earth node containing all 4 different layers
    var earthNode = EarthNode()
    
    // Camera node specific for orbiting around the Earth node when panning
    let cameraOrbit = SCNNode()
    
    public override init(frame: CGRect) {
        super.init(frame: frame, options: nil)
        
        backgroundColor = .clear
        autoenablesDefaultLighting = true
        
        // Creating the main scene
        let mainScene = SCNScene()
        
        cameraNode.position = SCNVector3Make(0, 1.3, 1.8)
        cameraNode.camera = SCNCamera()
        
        cameraOrbit.addChildNode(cameraNode)
        
        mainScene.rootNode.addChildNode(cameraOrbit)
        
        // Initlizing and adding the Earth node to the scene
        earthNode = EarthNode()
        mainScene.rootNode.addChildNode(earthNode)
        
        scene = mainScene
        
        panGest = UIPanGestureRecognizer(target: self, action: #selector(panGestAc(sender:)))
        addGestureRecognizer(panGest)
    }
    
    /**
     Used for moving the camera along the xyz axis
     - parameters:
     - position: Final camera position
     - duration: of the animation in seconds
     */
    func moveCamera(position: SCNVector3, duration: TimeInterval) {
        cameraNode.runAction(SCNAction.move(to: position, duration: duration).applyTiming())
    }
    
    /**
     Used for orbiting the camera around the Earth node
     - parameters:
     - x: orbit x position
     - y:  orbit y position
     - z:  orbit z position
     - duration: of the animation in seconds
     */
    func orbitCamera(x: CGFloat = 0, y: CGFloat = 0, z: CGFloat = 0, duration: TimeInterval) {
        lastWidthRatio = (y / CGFloat.pi / -2).truncatingRemainder(dividingBy: 1)
        cameraOrbit.runAction(SCNAction.rotateTo(x: x, y: y, z: z, duration: duration).applyTiming())
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    var lastWidthRatio: CGFloat = 0
    var lastHeightRatio: CGFloat = 0
    
    @objc func panGestAc(sender: UIPanGestureRecognizer) {
        
        let translation = sender.translation(in: sender.view!)
        let widthRatio = translation.x / sender.view!.frame.size.width + lastWidthRatio
        let heightRatio = translation.y / sender.view!.frame.size.height + lastHeightRatio
        
        cameraOrbit.eulerAngles.y = Float.pi * -2 * Float(widthRatio)
        cameraOrbit.eulerAngles.x = -Float.pi * Float(heightRatio)
        
        if sender.state == .ended {
            
            var lastYAxis: CGFloat = CGFloat(cameraOrbit.eulerAngles.y)
            if (superview as! MainView).viewIndex == 1 {
                lastYAxis = 0.23
            }
            
            lastWidthRatio = (lastYAxis / CGFloat.pi / -2).truncatingRemainder(dividingBy: 1)
            lastHeightRatio = 0
            
            orbitCamera(y: lastYAxis, duration: 0.5)
        }
    }
}

public class EarthNode: SCNNode {
    
    // Earth nodes
    
    var earthNode: SCNNode!
    
    var mainHalf: SCNNode!
    var mantleMain: SCNNode!
    var outerMain: SCNNode!
    
    var inner: SCNNode!
    
    var secondHalf: SCNNode!
    var mantleSecond: SCNNode!
    var outerSecond: SCNNode!
    
    var layersArrayMain = [SCNNode]()
    
    public override init() {
        super.init()
        
        // Getting the Earth node from the scene
        let earthScene = SCNScene(named: "art.scnassets/earthLast.scn")
        
        // Assigning public vars
        
        earthNode = (earthScene?.rootNode)!
        
        mainHalf = earthNode.childNode(withName: "MainHalf", recursively: true)
        
        outerMain = mainHalf.childNode(withName: "OuterMain", recursively: true)
        mantleMain = mainHalf.childNode(withName: "MantleMain", recursively: true)
        
        inner = earthNode.childNode(withName: "Inner", recursively: true)
        
        secondHalf = earthNode.childNode(withName: "SecondHalf", recursively: true)
        
        outerSecond = secondHalf.childNode(withName: "OuterMain", recursively: true)
        mantleSecond = secondHalf.childNode(withName: "MantleMain", recursively: true)
        
        // Adding the Earth node to the main node
        addChildNode(earthNode)
        
        layersArrayMain = [mainHalf.childNode(withName: "EarthMain", recursively: true)!, mantleMain, outerMain, inner]
        
        startRotation()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    /**
     Used to start the rotation animation of the Earth
     */
    func startRotation() {
        earthNode.runAction(SCNAction.repeatForever(SCNAction.rotateBy(x: 0, y: 2 * .pi, z: 0, duration: 200).applyTiming()))
    }
    
    /**
     Used to stop the rotation animation of the Earth
     */
    func stopRotation() {
        earthNode.removeAllActions()
        earthNode.runAction(SCNAction.rotateTo(x: 0, y: 0, z: 0, duration: 1.5).applyTiming())
    }
    
    var particlesMantle: SCNParticleSystem!
    var particlesOuter: SCNParticleSystem!
    var particlesInner: SCNParticleSystem!
    
    var particlesScaled = false
    
    /**
     Add particles to the Earth layer
     */
    func addParticles() {
        
        let particlesScene = SCNScene(named: "art.scnassets/particles.scn")?.rootNode
        particlesMantle = particlesScene?.childNode(withName: "particlesMantle", recursively: true)?.particleSystems?.first
        particlesOuter = particlesScene?.childNode(withName: "particlesOuter", recursively: true)?.particleSystems?.first
        particlesInner = particlesScene?.childNode(withName: "particlesInner", recursively: true)?.particleSystems?.first
        
        particlesMantle?.emitterShape = mantleMain.geometry
        particlesOuter?.emitterShape = outerMain.geometry
        
        mantleMain.addParticleSystem(particlesMantle!)
        outerMain.addParticleSystem(particlesOuter!)
        
        inner.addParticleSystem(particlesInner!)
    }
    
    /**
     Remove particles from the Earth layer
     */
    func removeParticles() {
        mantleMain.removeAllParticleSystems()
        outerMain.removeAllParticleSystems()
        inner.removeAllParticleSystems()
    }
    
    /**
     Scale the particles to match ARKit Scene
     */
    func scaleParticles(scale: CGFloat) {
        var scaleOrNot = true
        if scale < 1 {
            particlesScaled = true
        }else {
            if !particlesScaled {
                scaleOrNot = false
            }
            particlesScaled = false
        }
        
        if scaleOrNot {
            
            particlesMantle.birthRate *= scale
            particlesOuter.birthRate *= scale
            particlesInner.birthRate *= scale
            
            particlesMantle.particleSize *= scale == 0.2 ? 0.95 : 1/0.95
            particlesOuter.particleSize *= scale == 0.2 ? 0.95 : 1/0.95
            particlesInner.particleSize *= scale
        }
        
    }
}
